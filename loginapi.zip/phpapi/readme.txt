URL : http://{server-name}/{project-name}/api.php?action={action-name}

example : http://localhost/phpapi/api.php?action=login

